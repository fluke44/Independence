<?php
require_once "IMoveable.php";
require_once "exceptions.php";

class cRecordset implements IMoveable {
	protected $errNum = 0;
	protected $errMsg;
	protected $internalData = array();
	protected $mArray = array();
	protected $mFields = array();
	protected $isFieldsSet = false;
	protected $mPos = -1;
	protected $mSize = 0;
	
	Private $mnMaxRecords;
    Private $mnEndRecord;	//Zero-based index of last row to retrieve
    Private $mnStartRecord;	//First record to retrieve
    Private $mbGetTotalCount;
    Private $mbSelectDistinct; 
    Private $mnSelectTop;		//select top n
    Private $mbIncludeIDFields;
    Private $msGroupBy;
    Private $mnGroupByCount;
    
    public function __construct($aResult) {
    	while($records = $aResult->fetch_assoc()) {
			$this->AddRow();
			foreach($records as $key => $value) {
				if(!$this->isFieldsSet) $this->mFields[] = $key;
				$this->AddRecord($key, $value);
			}
			$this->isFieldsSet = true;
		}
    }
    
    public function GetInternalData($id) {
    	try {	
    		if(is_numeric($id)) {
    			return $this->internalData[$id];
    		} else {
    			return $this->internalData["$id"];
    		}
    	} catch (Exception $e) {
    		var_dump($e);
    		$this->SetError(1, "Identificator not found in InternalData");
    	}
    }
    
    public function SetInternalData($id, $value) {
    	if(!is_empty($id) AND !is_empty($value)) {
    		$this->internalData["$id"] = $value;
    	}
    }
    
    public function GetFields() {
    	return $this->mFields;
    }
	
	private function AddRow() {
		try {
			$this->mArray[] = new cRecordsetRow();
		} catch (AddRecordException $e) {
			echo $e->GetMsg();
		}
		$this->setSize();
		$this->mPos++;
	}
	
	public function AddRecord($col, $value) {
		$this->Row()->Add($col, $value);
	}
	
	public function Row() {
		return $this->mArray[$this->mPos];
	}
	
	public function AtBeginning() {
        return ($this->mPos < 1 || $this->mSize == 0);
	}

    public function AtEnd() {
        return ($this->mPos == $this->mSize || $this->mSize == 0);
    }
    
    public function Count() {
    	return count($this->mArray);
    }
    
    public function MoveFirst() {
		$this->mPos = 0;
		return $this->mPos;
	}
	
	public function MoveLast() {
		$this->mPos = $this->Count();
	}
	
	public function Clear() {
		$this->mArray = array();
		$this->mFields = array();
		$this->isFieldsSet = false;
		$this->mPos = -1;
		$this->mSize = 0;
		return $this->mPos;
	}
	
	public function MoveNext() {
		if(!$this->AtEnd()) {
			$this->mPos++;
			return $this->mPos;
		} else {
			return -1;
		}
	}
	
	public function MovePrevious() {
		if(!$this->AtBeginning()) {
			$this->mPos--;
			return $this->mPos;
		} else {
			return -1;
		}
	}
	
	protected function setSize() {
		$this->mSize = count($this->mArray);
		return $this->mSize;
	}
	
	public function DebugPrint() {
		$this->MoveFirst();
		print "cRecordset DebugPrint: <br />";
		foreach($this->mArray as $record) {
			print($record->DebugPrint()."<br />");
		}
	}
	
}

class cRecordsetRow extends cRecordset implements IMoveable {
	
	public function __construct() {
		
	}
	
	public function Add($col, $value) {
		$this->mArray[] = new cRecord($col, $value);
		$this->setSize();
		$this->mPos++;
	}
	
	public function DebugPrint() {
		//$this->Clear();
		foreach($this->mArray as $row) {
			print $row->GetColName().": ".$row->GetValue().", ";
		}
	}
	
	public function GetRecord() {
		return ($this->mArray[$this->mPos]);
	}
}

class cRecord {
	private $colName;
	private $value;
	
	public function __construct($colName, $value) {
		$this->colName = $colName;
		$this->value = $value;
	}
	
	public function GetColName() {
		return $this->colName;
	}
	
	public function GetValue() {
		return $this->value;
	}
}
?>